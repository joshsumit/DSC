﻿

$fullName = "C:\IACPipeline\MEP.IaC.Example\CD\VMConfiguration\FileServer.psm1"

$TemplateFile = "C:\Users\meptrainee\Desktop\prac\azuredeploy.json"
$TemplateParametersFile = "C:\Users\meptrainee\Desktop\prac\azuredeploy.parameters.json"
	$automationAccountResourceGroup = "sjvsvmrg"
 
	$automationAccountName ="sjvsvmrgautoacnt"

Import-AzureRmAutomationDscConfiguration -SourcePath $fullName `
											 -ResourceGroupName $automationAccountResourceGroup `
											 -AutomationAccountName $automationAccountName `
											 -Published -Force


	$automationJob = Start-AzureRmAutomationDscCompilationJob -ConfigurationName "FileServer" `
													 -ResourceGroupName $automationAccountResourceGroup `
													 -AutomationAccountName  $automationAccountName 




New-AzureRmResourceGroupDeployment  -Name   newdep102 `
                                   -ResourceGroupName $automationAccountResourceGroup `
                                   -TemplateFile $TemplateFile `
                                   -TemplateParameterFile $TemplateParametersFile `                                   


Get-AzureRmAutomationDscNode  -ResourceGroupName $automationAccountResourceGroup `
											 -AutomationAccountName $automationAccountName ` |fl *