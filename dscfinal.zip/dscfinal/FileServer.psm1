Configuration FileServer
{
   

    Import-DscResource -ModuleName PSDesiredStateConfiguration
   # Import-DscResource -ModuleName 'xWebAdministration'

    Node Shared
    {
		File ShareFolder 
        {
            Ensure = 'Present'
            DestinationPath = "c:\shared"
            Type = 'Directory'
        }
        	WindowsFeature IIS
        {
            Ensure          = "Present"
            Name            = "Web-Server"
            IncludeAllSubFeature = $true 
        }
		File FileDemo {
           DestinationPath = 'C:\inetpub\wwwroot\iisstart.htm'
           Ensure = "Present"
           Contents = 'MEP IDC DevOps Expert Training'
       }
}
}
